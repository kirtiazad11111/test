package 'tree' do
	action:install

end

package 'ntp' do
	action:install

end

package 'git'

package 'emacs' do
	action:install
end

template '/etc/motd' do
	source 'motd.erb'
	action:create

variables(
	:name => 'Chefuser'
)


#file 'etc/motd' do
#	action:delete
end
