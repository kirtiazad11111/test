file 'hello.txt' do
	content 'hello again :testing calling recipe from another recipe exec'
	mode '0776'
	user 'root'
	group 'root'
end
