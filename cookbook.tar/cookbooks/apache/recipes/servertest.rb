#
# Cookbook:: apache
# Recipe:: servertest
#
# Copyright:: 2018, The Authors, All Rights Reserved.


package 'apache2' do
        action :install
end

remote_file '/var/www/html/HopetounFalls.jpg' do
	source 'https://upload.wikimedia.org/wikipedia/commons/3/36/Hopetoun_falls.jpg'
end

template '/var/www/html/index.html' do
#        content "<H1>Hello world again </H1>
#	<h2> IPAdress: #{node['ipaddress']} </h2>
#	<h3> Hostname: #{node['hostname']} </h3>
#	<h4> Available Memory: #{node['memory']['available']} </h4>"
	source 'index.html.erb'
	action:create
end

execute "run a sccript" do
	command <<-EOH
	mkdir /var/www/mysites/ /
	chown -R test /var/www/mysites/ /
	group "root"
	EOH
	
	not_if
end







service 'apache2' do
        action [:enable,:start ]
end
